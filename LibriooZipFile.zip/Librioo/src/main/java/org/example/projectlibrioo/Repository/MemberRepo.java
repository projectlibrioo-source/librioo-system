package org.example.projectlibrioo.Repository;

import org.example.projectlibrioo.Model.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MemberRepo extends JpaRepository<Member, Integer> {

    Member findUserByLibraryID(int libraryID);
}
